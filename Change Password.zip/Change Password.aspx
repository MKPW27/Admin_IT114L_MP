﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ChangePassword.aspx.cs" Inherits="Admin_IT114L_MP.WebForm2" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Change Password</title>
</head>
<body>
<form id="form1" runat="server">
<div>

Old Password:
<asp:TextBox ID="txtCurrentPassword" runat="server" TextMode="Password"></asp:TextBox>
<asp:RequiredFieldValidator ID="RFVcp" runat="server" ControlToValidate="txtCurrentPassword" ErrorMessage="*" ForeColor="Red"></asp:RequiredFieldValidator>
<br /><br />

New Password:
<asp:TextBox ID="txtNewPassword1" runat="server" TextMode="Password"></asp:TextBox>
<asp:RequiredFieldValidator ID="RFVnp" runat="server" ControlToValidate="txtNewPassword1" ErrorMessage="*" ForeColor="Red"></asp:RequiredFieldValidator>
<br /><br />

Re-enter New Password:
<asp:TextBox ID="txtNewPassword2" runat="server" TextMode="Password"></asp:TextBox>
<asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtNewPassword2" ErrorMessage="*" ForeColor="Red"></asp:RequiredFieldValidator>

<asp:CompareValidator 
ID="CompareValidator1"
runat="server"
ControlToValidate="txtNewPassword2"
ControlToCompare="txtNewPassword1"
ErrorMessage="Passwords do not match"
ForeColor="Red">
</asp:CompareValidator>

<br /><br />

<asp:Button ID="BTNsubmit" runat="server" Text="Change Password" OnClick="BTNsubmit_Click"/>

<br /><br />
<asp:Label ID="lblMessage" runat="server"></asp:Label>

</div>
</form>
</body>
</html>