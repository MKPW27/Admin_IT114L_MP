﻿using System;
using System.Data.OleDb;
using System.Web.UI;

namespace Admin_IT114L_MP
{
    public partial class WebForm2 : System.Web.UI.Page
    {

        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
            System.Web.HttpContext.Current.Server.MapPath("~/App_Data/information_admin.mdb");

        protected void Page_Load(object sender, EventArgs e)
        {
           
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

          
            if (Session["Username"] == null)
            {
                Response.Redirect("loginPage.aspx");
            }
        }

        protected void BTNsubmit_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;

            string username = Session["Username"].ToString();
            string oldPassword = txtCurrentPassword.Text.Trim();
            string newPassword1 = txtNewPassword1.Text.Trim();
            string newPassword2 = txtNewPassword2.Text.Trim();

            if (newPassword1 != newPassword2)
            {
                lblMessage.Text = "Passwords do not match.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            using (OleDbConnection con = new OleDbConnection(connString))
            {
                con.Open();

                OleDbCommand checkCmd = new OleDbCommand(
                "SELECT COUNT(*) FROM Users WHERE Username=? AND [Password]=?", con);

                checkCmd.Parameters.AddWithValue("@Username", username);
                checkCmd.Parameters.AddWithValue("@Password", oldPassword);

                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count == 1)
                {
                    OleDbCommand updateCmd = new OleDbCommand(
                    "UPDATE Users SET [Password]=? WHERE Username=?", con);

                    updateCmd.Parameters.AddWithValue("@Password", newPassword1);
                    updateCmd.Parameters.AddWithValue("@Username", username);

                    updateCmd.ExecuteNonQuery();

                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Password successfully changed.";
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Old password is incorrect.";
                }
            }
        }
    }
}